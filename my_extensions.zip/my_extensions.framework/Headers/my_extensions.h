//
//  my_extensions.h
//  my-extensions
//
//  Created by Habib Durodola on 10/1/18.
//  Copyright © 2018 Habib Durodola. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for my_extensions.
FOUNDATION_EXPORT double my_extensionsVersionNumber;

//! Project version string for my_extensions.
FOUNDATION_EXPORT const unsigned char my_extensionsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <my_extensions/PublicHeader.h>


